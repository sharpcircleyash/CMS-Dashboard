<p align="center">Laravel Admin Dashboard
</p>

## About Project


Laravel Admin Dashboard with Auth.


### Installation Instructions

- ** Run git clone https://github.com/sharpcircleyash/CMS-Dashboard.git CMS-Dashboard
- ** Create a MySQL database for the project
- ** mysql -u root -p
- ** create database cms_laravel;
- ** Configure your .env file
- ** Run composer update from the projects root folder
- ** From the projects root folder run:
        From the projects root folder run php artisan key:generate
        From the projects root folder run php artisan migrate
        From the projects root folder run php artisan serve
- ** Run http://127.0.0.1:8000 on browser
- ** Use login credential:
        Username::admin@admin.com
        Password::123456